import json
import asyncio
import os
import re
import requests
import discord
from discord.ext import commands

bot = commands.Bot(command_prefix='.', intents=discord.Intents.all())
bot.remove_command('help')

@bot.event
async def on_ready():
    print(f"Logged in as: {bot.user.name} ({bot.user.id})")
    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.playing, name=".help"))

async def update_balance(webhook_message):
    with open('database.json', 'r') as f:
        data = json.load(f)

        if not webhook_message.content:
            return

        growIdMatch = re.search(r'GrowID: (\S+)', webhook_message.content)
        depositMatch = re.search(r'Deposit: (\d+) (World Lock|Diamond Lock)', webhook_message.content)

        if growIdMatch and depositMatch:
            growId = growIdMatch.group(1)
            deposit = int(depositMatch.group(1))
            if depositMatch.group(2) == 'Diamond Lock':
                deposit *= 100

            user_found = False
            for user in data:
                if user['name'] == growId:
                    user['balance'] += deposit
                    with open('database.json', 'w') as f:
                        json.dump(data, f)
                    await webhook_message.channel.send(f"Balance for user **{growId}** updated to **{user['balance']}**")
                    user_found = True
                    break

            if not user_found:
                await webhook_message.channel.send("User not found in database")

@bot.event
async def on_message(message):
    if message.channel.id == 1078640293760479272 and message.webhook_id: #ganti channel id tempat webhook donation log
        await update_balance(message)

    await bot.process_commands(message)

@bot.command()
async def help(ctx):
    if ctx.author.id == 1028741592242196490: # ganti dengan owner id lu
        message = ".help\n.set <growid>\n.bal\n.depo\n.info\n.stock\n.buy <code product> <amount>\n\n.addbal <tag user> <jumlah balance>\n.addp <nama produk> <code> <harga>\n.remove <code produk>\n.adds <code produk> <cid/lisensi/rdp>\n.change <world> <owner>"
    else:
        message = ".help\n.set <growid>\n.bal\n.depo\n.info\n.stock\n.buy <code product> <amount>"
    embed = discord.Embed(title="Bot Commands", color=discord.Color.green())
    embed.description = message
    await ctx.reply(embed=embed)

@bot.command()
async def set(ctx, name):
    user_balance = 0
    user_id = ctx.author.id

    try:
        with open('database.json') as f:
            database = json.load(f)
    except (FileNotFoundError, json.decoder.JSONDecodeError):

        with open('database.json', 'w') as f:
            json.dump([], f)
        database = []

    if any(user['name'] == name for user in database if user['user'] != user_id):
        embed = discord.Embed(title="Error", color=discord.Color.red())
        embed.description = f"Name `{name}` is already in use by another user.\nPlease choose a different name."
        await ctx.reply(embed=embed)
        return


    user_index = next((i for i, user in enumerate(database) if user['user'] == user_id), -1)
    if user_index != -1:

        database[user_index]['name'] = name
    else:

        database.append({'user': user_id, 'name': name, 'balance': user_balance})

    with open('database.json', 'w') as f:
        json.dump(database, f)

        embed = discord.Embed(title="Success", color=discord.Color.green())
        embed.description = f"Your GrowID has been set to: {name}"
        await ctx.reply(embed=embed)

@bot.command()
async def bal(ctx):
    user_id = ctx.author.id

    with open('database.json', 'r') as f:
        data = json.load(f)

    user = next((user for user in data if user['user'] == user_id), None)
    if user is None:
        return await ctx.reply(f"You don't have an account yet. Please `/set <name>` first.")

    name = user['name']
    balance = user['balance']

    embed = discord.Embed(title=f"Your Balance is {balance} <:emoji_9:1071815138430160997>", color=discord.Color.green())

    await ctx.reply(embed=embed)

@bot.command()
async def info(ctx, member: discord.Member = None):
    if not member:
        member = ctx.author
    
    with open('database.json', 'r') as f:
        data = json.load(f)
    
    for item in data:
        if item['user'] == member.id:
            name = item['name']
            balance = item['balance']
            break
    else:
        embed = discord.Embed(title="Error", color=discord.Color.red())
        embed.description = f"User {member.mention} not found in database."
        await ctx.reply(embed=embed)
    
    embed = discord.Embed(title="User Information", color=discord.Color.green())
    embed.description = f"<a:oemji:1085835206973460480>GrowID: {name}\n<a:oemji:1085835206973460480>Balance: {balance} <:emoji_9:1071815138430160997>"
    await ctx.reply(embed=embed)

with open('database.json', 'r') as f:
    data = json.load(f)

@bot.command()
async def wb(ctx, *, text):
    webhook_url = "https://discord.com/api/webhooks/1094481560939528212/9ntgtRJadY2V9iF0tlggDqi2vRxY6EZAZOtXcg_J9mHOpgFPLo5KbfLaj_sM1USXNMoC"
    data = {"content": text}
    response = requests.post(webhook_url, json=data)
    if response.status_code == 204:
        await ctx.reply("Teks berhasil dikirim ke webhook.")
    else:
        await ctx.reply("Tidak dapat mengirim teks ke webhook.")

@bot.command()
async def addp(ctx, *args):
    if ctx.author.id != 1028741592242196490: # ganti dengan owner id lu
        await ctx.reply("?")
        return
    
    name = " ".join(args[:-2])
    code = args[-2]
    price = args[-1]
    stock = ""

    with open("sell.json", "r") as f:
        data = json.load(f)
    
    new_product = {
        "name": name,
        "code": code,
        "price": price,
        "stock": stock
    }
    
    data.append(new_product)
    
    with open("sell.json", "w") as f:
        json.dump(data, f)
    
        embed = discord.Embed(title="Success", color=discord.Color.green())
        embed.description = f"Produk berhasil ditambahkan"
        await ctx.reply(embed=embed)

@bot.command()
async def remove(ctx, code: str):
    if ctx.author.id != 1028741592242196490: # ganti dengan owner id lu
        await ctx.reply("?")
        return

    with open("sell.json", "r") as f:
        data = json.load(f)
    
    for i in range(len(data)):
        if data[i]["code"] == code:
            del data[i]
            break
    else:

        embed = discord.Embed(title="Error", color=discord.Color.red())
        embed.description = f"Tidak ada produk dengan kode {code}"
        await ctx.reply(embed=embed)
        return
    
    with open("sell.json", "w") as f:
        json.dump(data, f, indent=4)
    
    embed = discord.Embed(title="Success", color=discord.Color.green())
    embed.description = f"Produk dengan kode {code} berhasil dihapus"
    await ctx.reply(embed=embed)

@bot.command()
async def adds(ctx, code: str, *args):
    if ctx.author.id != 1028741592242196490: # ganti dengan owner id lu
        await ctx.reply("?")
        return
    data = ", ".join(args)

    with open("sell.json", "r+") as f:
        products = json.load(f)

        for product in products:
            if product["code"] == code:
                product["stock"] = data
                break
        else:
            embed = discord.Embed(title="Error", color=discord.Color.red())
            embed.description = f"Tidak ada produk dengan code {code}"
            await ctx.reply(embed=embed)
            return

        f.seek(0)
        json.dump(products, f, indent=4)
        f.truncate()

        embed = discord.Embed(title="Success", color=discord.Color.green())
        embed.description = f"Stock berhasil ditambahkan ke produk dengan code {code}"
        await ctx.reply(embed=embed)

@bot.command()
async def buy(ctx, code, quantity):

    with open("sell.json", "r") as f:
        data = json.load(f)
    product = next((p for p in data if p["code"] == code), None)

    if product is None:
        embed = discord.Embed(title="Error", color=discord.Color.red())
        embed.description = f"Tidak ditemukan produk dengan code {code}"
        await ctx.reply(embed=embed)
        return

    try:
        quantity = int(quantity)
    except ValueError:
        embed = discord.Embed(title="Error", color=discord.Color.red())
        embed.description = f"Jumlah pembelian harus angka\ncontoh: .buy rdp 1"
        await ctx.reply(embed=embed)
        return

    stock = product["stock"].split(", ")
    if len(stock) < quantity:
        embed = discord.Embed(title="Error", color=discord.Color.red())
        embed.description = f"Mohon cek stock yang tersisa"
        await ctx.reply(embed=embed)
        return

    with open("database.json", "r") as f:
        db = json.load(f)
    user = next((u for u in db if u["user"] == ctx.author.id), None)

    if user is None:
        embed = discord.Embed(title="Error", color=discord.Color.red())
        embed.description = f"Mohon lakukan .set <gowid> sebelum membeli"
        await ctx.reply(embed=embed)
        return

    price = int(product["price"])
    total_price = price * quantity

    if user["balance"] < total_price:
        embed = discord.Embed(title="Error", color=discord.Color.red())
        embed.description = f"Balance anda tidak cukup"
        await ctx.reply(embed=embed)
        return

    message = f"Anda telah membeli **{quantity}** buah produk seharga **{total_price}** <:emoji_9:1071815138430160997>\n\n"
    message += f"<:yow:1094927867030290512> `{', '.join(stock[:quantity])}`\n"
    
    embed = discord.Embed(title="Pembelian Berhasil", description=message, color=discord.Color.green())
    await ctx.author.send(embed=embed)

    product["stock"] = ", ".join(stock[quantity:])
    with open("sell.json", "w") as f:
        json.dump(data, f)

    user["balance"] -= total_price
    with open("database.json", "w") as f:
        json.dump(db, f)

        embed = discord.Embed(title="Success", color=discord.Color.green())
        embed.description = f"Silahkan cek DM"
        await ctx.reply(embed=embed)

@bot.command()
async def stock(ctx):
    with open("sell.json", "r") as f:
        data = json.load(f)
    
    if len(data) == 0:
        embed = discord.Embed(title="Error", color=discord.Color.red())
        embed.description = f"Tidak ada produk yang dijual saat ini"
        await ctx.reply(embed=embed)
    else:
        message = ""
        for product in data:
            stock_count = len(product['stock'].split(',')) if product['stock'] else 0
            message += f"--------------------------------------------\n<:yow:1094927867030290512> Product: {product['name']}\n<:yow:1094927867030290512> Stock: {stock_count}\n<:yow:1094927867030290512> Code: {product['code']}\n<:yow:1094927867030290512> Price: {product['price']} <:emoji_9:1071815138430160997>\n"
        
        embed = discord.Embed(title="List Produk", color=discord.Color.blue(), description=message)
        await ctx.reply(embed=embed)

@bot.command()
async def depo(ctx):
    with open("depo.json", "r") as f:
        data = json.load(f)

    world = data.get("world", 0)
    owner = data.get("owner", 0)

    message = f"**World: {world}\nOwner: {owner}**"

    embed = discord.Embed(color=discord.Color.green())
    embed.title = message

    await ctx.send(embed=embed)

@bot.command()
async def change(ctx, world: str, owner: str):
    if ctx.author.id != 1028741592242196490: # ganti dengan owner id lu
        await ctx.reply("Anda tidak memiliki izin untuk menggunakan perintah ini.")
        return

    with open("depo.json", "r") as f:
        data = json.load(f)
    

    data["world"] = world
    data["owner"] = owner
    
    with open("depo.json", "w") as f:
        json.dump(data, f)
    
    embed = discord.Embed(title="Success change world depo", color=discord.Color.green())
    await ctx.reply(embed=embed)

@bot.command()
async def join(ctx, invite):
    try:
        guild = await bot.fetch_invite(invite)
        await guild.accept_invite()
        await ctx.send(f"Saya berhasil bergabung ke server {guild.name}!")
    except discord.errors.NotFound:
        await ctx.send("Tautan undangan tidak valid atau sudah kedaluwarsa.")
    except discord.errors.HTTPException:
        await ctx.send("Gagal bergabung ke server.")


@bot.command()
async def addbal(ctx, user: commands.MemberConverter, amount: int):

    if ctx.author.id != 1028741592242196490:
        await ctx.reply("?")
        return

    for entry in data:
        if entry['user'] == user.id:
            
            entry['balance'] += amount
            with open('database.json', 'w') as f:
                json.dump(data, f, indent=4)

            embed = discord.Embed(title="Success", color=discord.Color.green())
            embed.description = f"Added {amount} balance to {user.mention}\nNow {user.display_name} balance is {entry['balance']} <:emoji_9:1071815138430160997>"
            await ctx.reply(embed=embed)
            return

    embed = discord.Embed(title="Error", color=discord.Color.red())
    embed.description = f"User not found"
    await ctx.reply(embed=embed)

async def main():
    await bot.start('token bot lu')
    await check_database()

if __name__ == '__main__':
    asyncio.run(main())