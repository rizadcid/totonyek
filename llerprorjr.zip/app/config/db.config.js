/*
==========[LOPCY DEVELOPMENT]==========
   Created By : Lopcy#0998
   Helped By : Thea#1367
   
   Note : Please don't delete this, appreciate whoever made this project
==========[LOPCY DEVELOPMENT]==========
*/

module.exports = {
  url: "mongodb+srv://tssk:tssk@lisen.cr4mhxo.mongodb.net/?retryWrites=true&w=majority"
};

/*
==========[LOPCY DEVELOPMENT]==========
   Created By : Lopcy#0998
   Helped By : Thea#1367
   
   Note : Please don't delete this, appreciate whoever made this project
==========[LOPCY DEVELOPMENT]==========
*/