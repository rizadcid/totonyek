/*
==========[LOPCY DEVELOPMENT]==========
   Created By : Lopcy#0998
   Helped By : Thea#1367
   
   Note : Please don't delete this, appreciate whoever made this project
==========[LOPCY DEVELOPMENT]==========
*/

module.exports = app => {
    const licenses = require("../controllers/license.controller.js");
    var router = require("express").Router();
    router.get("/create/", licenses.create);
    router.get("/delete/:id", licenses.delete);
    router.get("/", licenses.findAll);
    router.post("/:licen/", licenses.findOne);
    app.use("/api/growtopia/license", router);
};

/*
==========[LOPCY DEVELOPMENT]==========
   Created By : Lopcy#0998
   Helped By : Thea#1367
   
   Note : Please don't delete this, appreciate whoever made this project
==========[LOPCY DEVELOPMENT]==========
*/