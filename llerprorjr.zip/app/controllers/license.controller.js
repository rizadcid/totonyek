/*
==========[LOPCY DEVELOPMENT]==========
   Created By : Lopcy#0998
   Helped By : Thea#1367
   
   Note : Please don't delete this, appreciate whoever made this project
==========[LOPCY DEVELOPMENT]==========
*/

const db = require("../models");
const License = db.license;
const Crypto = require("crypto");
const config = require("../../config.json");

exports.create = (req, res) => {
    const license = new License({
        license: Crypto.randomBytes(5).toString('hex').toLocaleUpperCase(),
        hwid: [],
        time: null
    });

    license
        .save(license)
        .then(data => {
            res.send(data);
        })
        .catch(err => {
            res.status(500).send({
                message:
                    err.message || "Some error occurred while creating the License."
            });
        });
};

exports.findAll = (req, res) => {
    License.find()
        .then(data => {
            res.send(data);
        })
        .catch(err => {
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving License."
            });
        });
};

exports.findOne = (req, res) => {
    const licen = req.params.licen;
    const hwid = req.body.hwid;
    if (!licen) return res.status(404).send({ message: "Missing arguments" })
    License.findOne({ license: licen })
        .then(data => {
            var date = new Date()
            if (!data) return res.status(404).send({ message: "Not found License with id " + id });
            if (data.time !== null && Math.floor((date.setDate(date.getDate())) / 1000) > data.time) return res.status(403).send({ message: "License expired" });
            if (data.hwid.includes(hwid)) return res.status(200).send(hwid);
            if (data.hwid.length >= config.maxDevice) return res.status(403).send({ message: "HWID full" });
            let hwids = data.hwid
            hwids.push(hwid)
            let license_date = data.time == null ? Math.floor((date.setDate(date.getDate() + config.expiredDate)) / 1000) : data.time
            data.hwid = hwids
            data.time = license_date
            data.save()
            res.status(200).send(hwid);
        })
        
        .catch(err => {
            res
                .status(500)
                .send({ message: "Error retrieving License with id=" + id });
        });
};

exports.delete = (req, res) => {
  const id = req.params.id;

  License.findByIdAndRemove(id)
    .then(data => {
      if (!data) {
        res.status(404).send({
          message: `Cannot delete License with id=${id}. Maybe License was not found!`
        });
      } else {
        res.send({
          message: "License was deleted successfully!"
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Could not delete License with id=" + id
      });
    });
};

/*
==========[LOPCY DEVELOPMENT]==========
   Created By : Lopcy#0998
   Helped By : Thea#1367
   
   Note : Please don't delete this, appreciate whoever made this project
==========[LOPCY DEVELOPMENT]==========
*/