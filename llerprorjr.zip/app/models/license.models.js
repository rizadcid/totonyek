/*
==========[LOPCY DEVELOPMENT]==========
   Created By : Lopcy#0998
   Helped By : Thea#1367
   
   Note : Please don't delete this, appreciate whoever made this project
==========[LOPCY DEVELOPMENT]==========
*/

module.exports = mongoose => {
    var schema = mongoose.Schema(
        {
            license: String,
            hwid: Array,
            time: Number || null
        }
    );

    schema.method("toJSON", function () {
        const { __v, _id, ...object } = this.toObject();
        object.id = _id;
        return object;
    });

    const License = mongoose.model("license", schema);
    return License;
};

/*
==========[LOPCY DEVELOPMENT]==========
   Created By : Lopcy#0998
   Helped By : Thea#1367
   
   Note : Please don't delete this, appreciate whoever made this project
==========[LOPCY DEVELOPMENT]==========
*/