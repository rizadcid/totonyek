/*
==========[LOPCY DEVELOPMENT]==========
   Created By : Lopcy#0998
   Helped By : Thea#1367
   
   Note : Please don't delete this, appreciate whoever made this project
==========[LOPCY DEVELOPMENT]==========
*/

const dbConfig = require("../config/db.config.js");
const mongoose = require("mongoose");

const db = {};
db.mongoose = mongoose;
db.url = dbConfig.url;
db.license = require("./license.models.js")(mongoose);

module.exports = db;

/*
==========[LOPCY DEVELOPMENT]==========
   Created By : Lopcy#0998
   Helped By : Thea#1367
   
   Note : Please don't delete this, appreciate whoever made this project
==========[LOPCY DEVELOPMENT]==========
*/