const express = require("express");
const cors = require("cors");
const db = require("./app/models");
const Crypto = require("crypto");
const licenses = require("./app/controllers/license.controller.js");
const License = db.license
const app = express();
const {
  WebhookClient,
  EmbedBuilder
} = require("discord.js");
const config = require("./config.json");
const webhookId = config.webhookId;
const webhookToken = config.webhookToken;
const messageId = config.messageId;
const webhookClient = new WebhookClient({ id: webhookId, token: webhookToken });
var corsOptions = {
  origin: "*"
};

app.use(cors(corsOptions));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

db.mongoose
  .connect(db.url)
  .then(() => {
    console.log("Connected to the database!");
  })
  .catch(err => {
    console.log("Cannot connect to the database!");
    process.exit();
  });

app.get("/", (req, res) => {
  res.json({ message: "TSSK LICENSE API" })
});

require("./app/routes/license.routes")(app)
// make sistem up timer
const startTime = Date.now();
const uptime = Date.now() - startTime;

// math random 
const randomNumber = Math.floor(Math.random() * 100) + 1;
const randomNumber2 = Math.floor(Math.random() * 1024) + 500;


// Create a function to generate a random color
function getRandomColor() {
  // Generate a random number between 0 and 16777215 (hexadecimal FFFFFF)
  const randomNumbers = Math.floor(Math.random() * 16777216);

  // Convert the number to a hexadecimal string and return it
  return '#' + randomNumbers.toString(16);
}
// set port, listen for requests
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
  if (config.useWebhook) {
    setInterval(() => {
      const embed = new EmbedBuilder()
        .setTitle("License System Status")
        .setColor(getRandomColor())
        .addFields(
          {
            name: "Script Stats", value: `**CREATE ID <a:Online:1010366511942225950>\nUpTime: ${uptime}ms**`, inline: true
          }, { name: `**System Stats**`, value: `Location :Not Found\nSoftware : NODE JS\nStorage : ${randomNumber2} USE\nCpu use : ${randomNumber} %`, inline: false }
        )
        .setTimestamp() // fix the method name here
        .setFooter({ text: "Last Updated" })
      webhookClient.editMessage(messageId, {
        embeds: [embed],
      });
    }, config.delayWebhook);
  }
});